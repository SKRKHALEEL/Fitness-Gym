export { default as Navbar } from "./navbar";
export { default as Link } from "./navbar/link";
export { default as Home } from "./home";
export { default as Benefits } from "./benefits";
export { default as OurClasses } from "./our-classes";
export { default as ContactUs } from "./contact-us";
export { default as Footer } from "./footer";
